---
name: Editorial Obsidian & Blush
colors:
  surface: '#fbf9f5'
  surface-dim: '#dbdad6'
  surface-bright: '#fbf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ef'
  surface-container: '#efeeea'
  surface-container-high: '#eae8e4'
  surface-container-highest: '#e4e2de'
  on-surface: '#1b1c1a'
  on-surface-variant: '#45474b'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f0ed'
  outline: '#76777b'
  outline-variant: '#c6c6cb'
  surface-tint: '#5d5e63'
  primary: '#06080c'
  on-primary: '#ffffff'
  primary-container: '#1e2024'
  on-primary-container: '#86878c'
  inverse-primary: '#c6c6cb'
  secondary: '#a83639'
  on-secondary: '#ffffff'
  secondary-container: '#fe7676'
  on-secondary-container: '#720b17'
  tertiary: '#010c01'
  on-tertiary: '#ffffff'
  tertiary-container: '#152412'
  on-tertiary-container: '#7b8d74'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e7'
  primary-fixed-dim: '#c6c6cb'
  on-primary-fixed: '#1a1c20'
  on-primary-fixed-variant: '#45474b'
  secondary-fixed: '#ffdad8'
  secondary-fixed-dim: '#ffb3b0'
  on-secondary-fixed: '#410006'
  on-secondary-fixed-variant: '#881d24'
  tertiary-fixed: '#d5e8cb'
  tertiary-fixed-dim: '#b9ccb0'
  on-tertiary-fixed: '#101f0d'
  on-tertiary-fixed-variant: '#3b4b36'
  background: '#fbf9f5'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2de'
typography:
  display:
    fontFamily: Outfit
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Outfit
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Outfit
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Outfit
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 30px
    letterSpacing: -0.01em
  title-lg:
    fontFamily: Outfit
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0em
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Manrope
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 3rem
  margin-sm: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
The design system establishes a premium, intellectual sanctuary for high-velocity creators, researchers, and AI builders. It balances the austere authority of high-end editorial publications with the soft, cognitive ease of a modern wellness retreat. 

The aesthetic is anchored in:
- **Quiet Authority**: Deep, structural charcoal tones (`#1E2024`) evoke precision instrument interfaces and bespoke physical stationery.
- **Cognitive Warmth**: Understated blush-coral accents cut through technical density, transforming cold computational outputs into an approachable, collaborative dialogue.
- **Architectural Clarity**: High-contrast typographic scales and razor-thin translucent boundaries replace heavy UI chrome, keeping focus squarely on community exchange and generated insights.

## Colors
The color palette relies on an organic light canvas punctuated by deep mineral darks and targeted chromatic warmth:

- **Primary (`#1E2024`)**: Deep charcoal serving as the dominant grounding force for typography, primary action surfaces, headers, and navigation frames.
- **Secondary (`#F87171`)**: A vibrant yet tempered blush-coral, used sparingly for active states, high-priority notifications, and signature call-to-actions.
- **Tertiary (`#8B9D83`)**: A muted sage green acting as a calming stabilizer for secondary badges, tag identifiers, and passive indicators.
- **Neutral Canvas (`#FBF9F5`)**: An off-white, warm cream surface providing low optical glare, high readability, and a tactile, linen-paper feel.
- **Accent Underlays**: Soft blush tint (`#FCECE7`) provides gentle contrast for subtle container fills, highlighted rows, and hover feedback loops.

## Typography
Typographic rhythm balances the sculptural, neo-grotesque geometry of **Outfit** for structural statements with the open, humanist rhythm of **Manrope** for extended analytical reading.

- Set display and headline trackers slightly tighter (`-0.03em` to `-0.01em`) to create dense, impactful editorial headers.
- Maintain a generous line-height on `body-md` (`24px` on `15px` base) to preserve breathing room within dense AI prompt feeds and community discussions.
- Use uppercase treatments exclusively on `label-sm` alongside widened letter-spacing (`0.05em`) for metadata, micro-tags, and section tickers.

## Layout & Spacing
The layout follows a fluid 12-column architecture constrained within an outer maximum boundary of 1440px to retain deliberate editorial framing.

- **Breakpoints**: Mobile (320px–767px, 4 columns), Tablet (768px–1023px, 8 columns), Desktop (1024px+, 12 columns).
- **Rhythm**: Spacing follows a 4px baseline. Group related micro-elements with `space-xs` and `space-sm`. Anchor card paddings dynamically: `space-md` on mobile, scaling to `space-lg` and `space-xl` across desktop views.
- **Section Contrast**: Fluid dark contrast blocks (rendered in `#121316` or `#1E2024`) span full edge-to-edge widths, breaking the warm neutral canvas to emphasize high-focus workflows such as prompt editors or code outputs.

## Elevation & Depth
Depth avoids heavy skeuomorphic drops in favor of atmospheric layering, frosted glass, and hairline boundaries:

- **Surface Layering**: The primary foundation rests on `#FBF9F5`. Elevated cards sit on crisp white (`#FFFFFF`) or frosted surfaces (`rgba(255, 255, 255, 0.75)` with `16px` backdrop blur).
- **Micro-Borders**: Floating elements feature ultra-fine 1px boundaries using `rgba(30, 32, 36, 0.08)` in light modes and `rgba(255, 255, 255, 0.12)` in dark contrast sections.
- **Ambient Diffusion**: Elevated planes utilize a dual-stage shadow system: an immediate contact shadow (`0 1px 2px rgba(30, 32, 36, 0.03)`) combined with a wide ambient plume (`0 12px 32px -4px rgba(30, 32, 36, 0.06)`).

## Shapes
A roundedness factor of `2` anchors the platform:

- **Base Radius (`0.5rem` / `8px`)**: Assigned to interactive micro-elements, inputs, dropdown menus, and pill tags.
- **Large Radius (`rounded-lg`, `1rem` / `16px`)**: Standard across interactive cards, prompt boxes, and contextual community panels.
- **Extra Large Radius (`rounded-xl`, `1.5rem` / `24px`)**: Reserved for structural hero containers, dashboard viewports, and modal overlays.
- Inner elements nested within containers must scale their radius inward by subtracting boundary padding to prevent awkward corner tension.

## Components

### Buttons
- **Primary**: Solid `#1E2024` surface, crisp white text (`#FFFFFF`), `0.5rem` radius. Subtle scale hover (`0.995`) with an ambient drop glow (`0 4px 12px rgba(30, 32, 36, 0.15)`).
- **Secondary**: Frosted white or warm `#FCECE7` tint with `#1E2024` text and a 1px boundary of `rgba(30, 32, 36, 0.1)`.
- **Accent (Signature)**: Warm coral (`#F87171`) fill with white text, strictly reserved for conversion-critical actions.

### Cards
- Constructed with `1rem` (`16px`) or `1.5rem` (`24px`) radius, an ultra-fine border (`1px solid rgba(30, 32, 36, 0.06)`), and an interior white fill or translucent frosted sheen.
- Hover states initiate a lift of `-2px` alongside an elevation opacity increase.

### Chips & Badges
- Filter chips and system tags use `0.5rem` radius with muted typography (`label-sm`).
- Categorical chips leverage `#8B9D83` (sage) tints for research status, and `#FCECE7` (blush) for featured or trending items.

### Form Inputs
- Single-line inputs and text areas utilize a clean white surface with an inset boundary of `rgba(30, 32, 36, 0.12)`.
- Active focus state shifts the border cleanly to `#1E2024` with an ambient ring: `0 0 0 3px rgba(30, 32, 36, 0.06)`.

### Selection Controls
- Checkboxes and radio discs carry a `1px` charcoal outline. Checked states fill with `#1E2024`, revealing a crisp white icon indicator.

### Community Thread List Item
- Borderless by default, using an alternating background hover of `rgba(30, 32, 36, 0.02)`.
- Includes a subtle left-aligned accent indicator bar in `#F87171` to demarcate unread or high-signal contributions.